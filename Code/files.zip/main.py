import cv2
import numpy as np
import os

# ==========================================
# ⚙️ БЛОК НАСТРОЕК (ПЕРЕМЕННЫЕ)
# ==========================================

# Теперь обрабатываем сразу несколько фотографий плат.
# Для каждой из них создаётся своя папка с отладочными кадрами.
INPUT_IMAGES = ['PCB.jpg', 'PCB2.png', 'PCB6.png']
OUTPUT_DIR_ROOT = 'debugging2'
# ==========================================


# =====================================================================
# 📐 ПОИСК КРУГЛЫХ МЕТОК (ФИДУЦИАЛЬНЫХ ОТВЕРСТИЙ)
# =====================================================================
def detect_circles(img):
    """
    Ищет круглые метки двумя взаимно дополняющими способами и объединяет
    результаты — это сильно повышает надёжность на разных фото:

    1) Адаптивная бинаризация + фильтр по круглости контура (как в
       исходном коде) — хорошо находит метки, полностью изолированные
       от остальной меди платы.
    2) Преобразование Хафа (HoughCircles) по изображению без бинаризации —
       находит метки, которые в бинарной маске "слиплись" с соседними
       дорожками и потеряли форму кольца (это как раз то, что происходило
       с угловыми метками на плате — рамка платы почти касается кольца).

    ВАЖНО (исправление реальной ошибки исходного кода):
    cv2.adaptiveThreshold у самого края изображения работает некорректно —
    окно локального среднего "залипает" на пикселях края (репликация
    границы), из-за чего метки, стоящие ровно в углах кадра, попросту не
    находились (проверено экспериментально на PCB.jpg — угловые метки
    пропадали из бинарной маски). Решение — отзеркалить изображение по
    краям (copyMakeBorder) перед порогом и обрезать паддинг обратно.
    """
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Размер ядра размытия подбираем от ширины кадра (как и в исходнике)
    blur_kernel = int(w / 400)
    if blur_kernel % 2 == 0:
        blur_kernel += 1
    blur_kernel = max(3, blur_kernel)
    gray_blurred = cv2.medianBlur(gray, blur_kernel)

    # --- Способ 1: адаптивная бинаризация + круглость контура ---
    ADAPTIVE_BLOCK_SIZE = 61
    ADAPTIVE_C = 10
    pad = ADAPTIVE_BLOCK_SIZE
    gray_padded = cv2.copyMakeBorder(gray_blurred, pad, pad, pad, pad, cv2.BORDER_REFLECT101)
    thresh_p = cv2.adaptiveThreshold(
        gray_padded, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
        cv2.THRESH_BINARY_INV, ADAPTIVE_BLOCK_SIZE, ADAPTIVE_C
    )
    thresh = thresh_p[pad:pad + h, pad:pad + w]

    contours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    MIN_CIRCULARITY = 0.4
    MAX_CIRCULARITY = 2
    MIN_AREA = int((w * 0.01) ** 2)
    MAX_AREA = int((w * 0.08) ** 2)

    detected = []
    for c in contours:
        area = cv2.contourArea(c)
        perimeter = cv2.arcLength(c, True)
        if perimeter == 0:
            continue
        circularity = 4 * np.pi * area / (perimeter ** 2)
        if MIN_CIRCULARITY < circularity < MAX_CIRCULARITY and MIN_AREA < area < MAX_AREA:
            M = cv2.moments(c)
            if M["m00"] != 0:
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
                radius = int(np.sqrt(area / np.pi))
                detected.append((cX, cY, radius))

    # --- Способ 2: преобразование Хафа (несколько порогов чувствительности) ---
    gray_for_hough = cv2.GaussianBlur(gray_blurred, (9, 9), 2)
    minR = int(w * 0.012)
    maxR = int(w * 0.05)
    for accum_thresh in (45, 35, 25):
        circles = cv2.HoughCircles(
            gray_for_hough, cv2.HOUGH_GRADIENT, dp=1.2, minDist=int(w * 0.08),
            param1=80, param2=accum_thresh, minRadius=minR, maxRadius=maxR
        )
        if circles is not None:
            for c in circles[0]:
                detected.append((int(c[0]), int(c[1]), int(c[2])))

    # Убираем дубликаты — оба метода часто находят одну и ту же метку
    merged = []
    min_dist = w * 0.02
    for d in detected:
        if not any(np.hypot(d[0] - m[0], d[1] - m[1]) < min_dist for m in merged):
            merged.append(d)

    return merged, thresh


# =====================================================================
# 📐 ПОИСК КОНТУРА САМОЙ ПЛАТЫ НА ФОТО
# =====================================================================
def detect_board_rect(img):
    """
    На "чистом" скане (PCB.jpg) плата занимает весь кадр, и её углы
    совпадают с углами изображения — так и работал исходный код.
    Но на фото с телефона (PCB2, PCB6) плата сфотографирована под углом,
    лежит на столе и не заполняет собой весь кадр целиком — в таком
    случае "угол кадра" и "угол платы" это разные точки, и без поправки
    ни одна метка возле реального угла платы не найдётся.

    Эта функция пытается отделить плату (оливковый текстолит) от фона
    (стол) по насыщенности цвета и яркости, и вернуть повёрнутый
    прямоугольник платы (cv2.minAreaRect). Возвращает None, если не
    получилось выделить достаточно большую область.
    """
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    sat = hsv[:, :, 1]

    _, sat_mask = cv2.threshold(sat, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    _, dark_mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    combo = cv2.bitwise_or(sat_mask, dark_mask)

    k = max(15, int(w * 0.02))
    kernel = np.ones((k, k), np.uint8)
    combo = cv2.morphologyEx(combo, cv2.MORPH_CLOSE, kernel)
    combo = cv2.morphologyEx(combo, cv2.MORPH_OPEN, kernel)

    contours, _ = cv2.findContours(combo, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea)
    if cv2.contourArea(c) < 0.15 * w * h:
        return None

    rect = cv2.minAreaRect(c)
    return cv2.boxPoints(rect)


def rect_target_positions(corners):
    """
    corners — 4 точки прямоугольника (в произвольном порядке, как их
    возвращает cv2.boxPoints). Возвращает 8 именованных целевых точек:
    4 угла + 4 середины сторон, независимо от порядка/поворота corners.
    """
    corners = np.array(corners, dtype=np.float64)
    center = corners.mean(axis=0)
    angles = np.arctan2(corners[:, 1] - center[1], corners[:, 0] - center[0])
    ordered = corners[np.argsort(angles)]
    # начинаем обход с точки, ближайшей к верхнему левому углу кадра
    start = np.argmin(ordered[:, 0] + ordered[:, 1])
    ordered = np.roll(ordered, -start, axis=0)

    names_corners = ["Верхний-Левый", "Верхний-Правый", "Нижний-Правый", "Нижний-Левый"]
    pts = {name: tuple(ordered[i]) for i, name in enumerate(names_corners)}
    pts["Верхний-Центр"] = tuple((ordered[0] + ordered[1]) / 2)
    pts["Правый-Центр"] = tuple((ordered[1] + ordered[2]) / 2)
    pts["Нижний-Центр"] = tuple((ordered[2] + ordered[3]) / 2)
    pts["Левый-Центр"] = tuple((ordered[3] + ordered[0]) / 2)
    return pts


CORNER_NAMES = {"Верхний-Левый", "Верхний-Правый", "Нижний-Левый", "Нижний-Правый"}


def match_zones(target_positions, circles, diag):
    """
    Для каждой из 8 целевых позиций ищем ближайшую найденную окружность.
    Для углов допуск больше, чем для середин сторон — угловые метки на
    фото под перспективой "гуляют" сильнее.
    """
    result = {}
    for name, (tx, ty) in target_positions.items():
        tolerance = diag * (0.16 if name in CORNER_NAMES else 0.07)
        best, best_dist = None, None
        for (cx, cy, r) in circles:
            dist = np.hypot(cx - tx, cy - ty)
            if dist < tolerance and (best_dist is None or dist < best_dist):
                best, best_dist = (cx, cy, r), dist
        if best is not None:
            result[name] = best
    return result


def process_image(input_path, output_dir_root):
    output_dir = os.path.join(output_dir_root, os.path.splitext(os.path.basename(input_path))[0])
    os.makedirs(output_dir, exist_ok=True)

    img = cv2.imread(input_path)
    if img is None:
        print(f"[ОШИБКА] Не удалось прочитать файл: {input_path}")
        return
    h, w = img.shape[:2]

    circles, thresh = detect_circles(img)
    cv2.imwrite(os.path.join(output_dir, 'step2_threshold.jpg'), thresh)

    img_all_valid_circles = img.copy()
    for (cx, cy, r) in circles:
        cv2.circle(img_all_valid_circles, (cx, cy), r, (255, 0, 0), 2)
    cv2.imwrite(os.path.join(output_dir, 'step4_detected_circles.jpg'), img_all_valid_circles)

    # Пробуем 2 гипотезы о положении платы в кадре и берём ту, которая
    # даёт больше совпавших меток: "плата = весь кадр" (как в исходнике,
    # подходит для ровного скана) и "плата = найденный поворотный
    # прямоугольник" (нужно для фото под углом на столе).
    full_frame_corners = np.array([[0, 0], [w, 0], [w, h], [0, h]], dtype=np.float64)
    board_corners = detect_board_rect(img)

    candidates = [("весь кадр", full_frame_corners)]
    if board_corners is not None:
        candidates.append(("контур платы", board_corners))

    best_label, best_matches, best_targets = None, {}, None
    for label, corners in candidates:
        targets = rect_target_positions(corners)
        diag = np.hypot(*(np.max(corners, axis=0) - np.min(corners, axis=0)))
        matches = match_zones(targets, circles, diag)
        if len(matches) > len(best_matches):
            best_label, best_matches, best_targets = label, matches, targets

    # Отрисовка и вывод информации
    img_final = img.copy()
    print(f"\n--- Результаты распознавания меток: {input_path} ---")
    print(f"    (система координат платы определена как: {best_label})")
    for zone_name, target_pos in best_targets.items():
        tx, ty = int(target_pos[0]), int(target_pos[1])
        if zone_name in best_matches:
            cX, cY, radius = best_matches[zone_name]
            print(f"[ НАЙДЕН ] {zone_name:15} -> Координаты: ({cX}, {cY}), Радиус: {radius}")
            cv2.circle(img_final, (cX, cY), radius + 5, (0, 255, 0), 3)
            cv2.circle(img_final, (cX, cY), 3, (0, 0, 255), -1)
            cv2.putText(img_final, zone_name, (cX - 40, cY - radius - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        else:
            print(f"[ОТСУТСТВУЕТ] {zone_name:15}")
            cv2.drawMarker(img_final, (tx, ty), (0, 0, 255), cv2.MARKER_CROSS, 20, 2)

    cv2.imwrite(os.path.join(output_dir, 'step5_final_corners.jpg'), img_final)

    # =====================================================================
    # 📐 БЛОК ВЫРАВНИВАНИЯ ПЕРСПЕКТИВЫ
    # =====================================================================
    dst_w = w
    dst_h = h
    return best_matches, best_targets


if __name__ == "__main__":
    for path in INPUT_IMAGES:
        process_image(path, OUTPUT_DIR_ROOT)
